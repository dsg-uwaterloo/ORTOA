package site.ycsb.db.waffle;

import java.util.*;

import site.ycsb.*;
import site.ycsb.Status;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;

import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Waffle binding for YCSB.
 */

public class WaffleClient extends DB {
  /**
   * Initialize any state for this DB. Called once per DB instance; there is one DB instance per client thread.
   */

  static {
    System.loadLibrary("waffle");
  }

  private native void nativeInit(int maxDeltaRead, int maxDeltaWrite, int cacheSize);
  
  private native void nativeCleanup();

  private native int nativeCreate(String key, byte[] data);

  private native byte[] nativeRead(String key);

  private native int nativeUpdate(String key, byte[] data);


  public void init() throws DBException {
    nativeInit(10, 10, 1140*100);
  }

  @Override
  public void cleanup() throws DBException {
    nativeCleanup();
  }

  private byte[] serializeValues(final Map<String, ByteIterator> values) throws IOException {
    try(final ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
      final ByteBuffer buf = ByteBuffer.allocate(4);

      for(final Map.Entry<String, ByteIterator> value : values.entrySet()) {
        final byte[] keyBytes = value.getKey().getBytes(UTF_8);
        final byte[] valueBytes = value.getValue().toArray();

        buf.putInt(keyBytes.length);
        baos.write(buf.array());
        baos.write(keyBytes);

        buf.clear();

        buf.putInt(valueBytes.length);
        baos.write(buf.array());
        baos.write(valueBytes);

        buf.clear();
      }
      return baos.toByteArray();
    }
  }

  private Map<String, ByteIterator> deserializeValues(final byte[] values, final Set<String> fields,
      final Map<String, ByteIterator> result) {
    final ByteBuffer buf = ByteBuffer.allocate(4);

    int offset = 0;
    while(offset < values.length) {
      buf.put(values, offset, 4);
      buf.flip();
      final int keyLen = buf.getInt();

      if(keyLen <= 0) {
        break;
      }

      buf.clear();
      offset += 4;
      final String key = new String(values, offset, keyLen);
      offset += keyLen;

      buf.put(values, offset, 4);
      buf.flip();
      final int valueLen = buf.getInt();
      buf.clear();
      offset += 4;

      if(fields == null || fields.contains(key)) {
        result.put(key, new ByteArrayByteIterator(values, offset, valueLen));
      }

      offset += valueLen;
    }

    return result;
  }

  @Override
  public Status insert(String table, String key, Map<String, ByteIterator> values) {
    try {
      byte[] serializedMap = serializeValues(values);
      //System.out.println("INSERT: SIZE=" + Integer.toString(serializedMap.length));
      nativeCreate(key, serializedMap);
      return Status.OK;
    } catch(IOException e) {
      return Status.ERROR;
    }
  }

  @Override
  public Status delete(String table, String key) {

    // Waffle does not provide a delete method

    return Status.OK;
  }

  @Override
  public Status read(String table, String key, Set<String> fields, Map<String, ByteIterator> result) {
    byte[] serializedMap = nativeRead(key);
    //System.out.println("READ: SIZE=" + Integer.toString(serializedMap.length));
    deserializeValues(serializedMap, fields, result);
    return Status.OK;
  }

  @Override
  public Status update(String table, String key, Map<String, ByteIterator> values) {
    try {
      byte[] serializedMap = serializeValues(values);
      //System.out.println("UPDATE: SIZE=" + Integer.toString(serializedMap.length));
      nativeUpdate(key, serializedMap);
      return Status.OK;
    } catch(IOException e) {
      return Status.ERROR;
    }
  }

  @Override
  public Status scan(String table, String startkey, int recordcount, Set<String> fields,
      Vector<HashMap<String, ByteIterator>> result) {

    // Waffle does not provide a scan method

    return Status.OK;
  }
}
